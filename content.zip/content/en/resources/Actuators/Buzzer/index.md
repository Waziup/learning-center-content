---
id: 1
title: Buzzer
type: actuator
desc: A buzzing or beeping audio signaling device2.
color: "#c2c2c2"
tags: []
wiring: |
  ![picxxyyzz](img/pic3.png)
  **Note:** Piezo buzzers have a + marking on top of their package to indicate which terminal is positive.



---
